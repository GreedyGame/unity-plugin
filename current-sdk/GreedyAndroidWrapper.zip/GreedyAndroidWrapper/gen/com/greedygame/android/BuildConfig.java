/** Automatically generated file. DO NOT MODIFY */
package com.greedygame.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}